---
marp: true
size: 4:3
theme: marjal
paginate: true
header: 11. Introducció a Symfony
footer: Desenvolupament d'aplicacions web
---

<!-- _class: lead -->
# Introducció a Symfony
---
1. Instalación y configuración de Symfony
    1. Arquitectura MVC
    2. Introducció a YAML
2. Vistes
   1. Motor de plantilles Twig
3. Injecció de dependències: Contenidors
4. El model
   1. Doctrine
5. Creació i validació de formularis
6. Seguretat i control d’accés
7. Symfony _Bundles_
---
## Frameworks PHP

Un **framework** és una eina que proporciona una sèrie de mòduls que
ajuden a organitzar i desenvolupar un producte de programari. 

La majoria dels _framewroks_ PHP proporcionen una sèrie
de comandos o eines per a crear projectes amb una estructura determinada
(normalment seguint el patró MVC), de manera que ja
donen una base de treball feta, i facilitats per a poder crear el model
de dades, la connexió a la base de dades, les rutes de les diferents
seccions de l'aplicació, etc.

---
## Frameworks PHP

-   **Laravel**, un framework relativament recent (va ser creat en
    2011).
-   **Symfony** , el framework que emprarem en aquest curs. Creat en
    2005.
-   **CodeIgniter**, un framework més lleuger que els anteriors. Va ser creat
    en 2006.
-   **Phalcon**, un altre framework de recent creació (2012).
-   **CakePHP**, creat en 2005, és un altre framework similar a
    CodeIgniter.
-   **Laminas**, evolució de Zend Framework creat en 2006.
-   ... etc.

--- 

## Recursos 

A l'hora de treballar amb Symfony (versió 5), necessitem:

-   Un servidor web que suporte PHP 7.4 o posterior. 
-   Un servidor de bases de dades en el qual emmagatzemar la informació
    de les nostres aplicacions. Emprarem un servidor MariaDB/MySQL.
-   PHP (versió 7.4 o posterior)
-   El propi framework Symfony.
-   Un IDE (entorn de desenvolupament) amb el qual editar el codi dels
    nostres projectes
-   Composer

---
## Iniciar el projecte Symfony

Hi ha dues alternatives per a crear projectes Symfony:

```shell
composer create-project symfony/skeleton project-name
```
Crearà un projecte amb el nom indicat en la carpeta actual,
contenint l'estructura mínima, sense llibreries de tercers. 

```shell
composer create-project symfony/website-skeleton project-name
```
Crearà el projecte amb totes els components tradicionals per crear un lloc web
complet.

---

## Projecte de prova

Per a començar, anem a crear un projecte anomenat "testing" amb la segona
opció. Accedim a la carpeta de treball (podem crear una en
/home/alumne/projectes-symfony, per exemple), i escrivim aquest comando des de
dins d'aqueixa carpeta:

```shell
composer create-project symfony/website-skeleton testing
```
---
## Estructura del projecte

En el cas concret d'un projecte Symfony 5, l'estructura queda com
segueix:

```shell
├── bin
├── composer.json
├── composer.lock
├── config
├── migrations
├── public
├── src
├── templates
├── tests
├── translations
├── var
└── vendor
```
---
#### La consola de Symfony

En la carpeta `bin` hi ha un parell d'arxius executables via PHP.

- `phpunit`, per a fer proves unitàries
- `console`, àmpliament utilitzat per a ajudar-nos a certes tasques, com per exemple
crear entitats, engegar un servidor de proves, examinar serveis, etc.

Prova a executar aquest comando en el projecte testing:

```shell
php bin/console debug:autowiring
```
---

## Introducció a YAML

Format emprat per a la configuració de projectes Symfony.

Més senzill que XML i que JSON, per exemple.

L'estàndard YAML és molt ampli (es pot consultar en el seu web
oficial), però per a Symfony només és necessari emprar un subconjunt
reduït. 

---

## Introducció a YAML

La informació s'estructura en parelles clau, valor. Si la clau
o el valor estan compostos per més d'una paraula separades per espais,
es tanquen entre cometes dobles (encara que no és habitual).

```yaml
driver: 'pdo_mysql'
```
---
## Introducció a YAML

>La jerarquia de la informació s'estableix mitjançant indentacions,
>però aquestes no han de fer-se amb el tabulador, sinó amb la barra
>espaciadora (quatre espais per nivell).

```yaml
default_table_options:
    charset: utf8mb
    collate: utf8mb4_unicode_ci
```
---
## Introducció a YAML
Pot haver-hi grups d'elements clau: valor, formant arrays. Aquests
arrays van entre claudàtors, en el cas d'arrays normals, o entre claus,
en el cas d'arrays associatius:

```yaml
rols: [ROLE_USER, ROLE_ADMIN]

users:
    admin: { password: adminpass, rols: [ROLE_ADMIN] }
    user: { password: userpass, rols: [ROLE_USER] }
```
---
## Introducció a YAML

També podem indicar una matriu (_array_) escrivint cada element en una nova línia 
que comence per `-`

```yaml
App\:
    resource: '../src/'
    exclude:
        - '../src/DependencyInjection/'
        - '../src/Entity/'
        - '../src/Kernel.php'
# exclude: ['../src/DependencyInjection/', '../src/Entity/', '../src/Kernel.php']        

```
---
## Introducció a YAML
Els comentaris s'indiquen amb un coixinet al principi de cada línia del
comentari.

```yaml
# in-memory users
users:
    admin: ...
```
---

## El patró MVC

![bg height:80%](../assets/mvc.png)

---

## Controladors i rutes en Symfony

Per a crear pàgines en una aplicació Symfony es necessiten dos elements:
1. Una **ruta** (és a dir, una URI que indique a quin contingut accedir de la
web) 
2. Un **controlador** associat a ella, que serà l'encarregat de mostrar
el resultat (la pàgina) per a aqueixa petició de ruta.

---
### El concepte de ruta en Symfony

Les rutes en Symfony poden ser (1) tradicionals o (2) amigables. 

```
http://movies-symfony/movie.php?id=12
```

```
http://movies-symfony/movies/12
```

---


##  El nostre primer controlador

```php
<?php
namespace App\Controller;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
class HomeController
{
    /**
     * @Route("/", name="home")
     */
    public function home()
    {
        return new Response("Welcome to movies web site");
    }
}
?>
```
Observeu el _namespace_ i els _use_

---


### Crear controladors per línia de comandos

Mitjançant el comando `bin/console` podem crear un controlador, amb la
instrucció:

```shell
php bin/console make:controller ControllerName
```

---

### Definint rutes

```php
/*** 
    @Route("/", name="home") 
*/ 
public function home() ...
```
---
##### Una altra forma de definir rutes: l'arxiu `config/routes.yaml`


```yaml
home: 
    path: /
    controller: App\Controller\HomeController::home
```
No obstant açò, si atenem a la documentació oficial de Symfony, **es
recomana definir les rutes mitjançant anotacions**.

---

### Comprovar les rutes de la nostra aplicació

Utilitzant la consola de Symfony (fitxer `bin/console` del nostre projecte)
podem comprovar quines rutes hi ha actualment definides en la nostra
aplicació, mitjançant aquest comando:

```shell
php bin/console debug:router
```

Mostrarà el llistat de rutes.

---

#### Configurar la reescriptura de rutes

```shell
composer require symfony/apache-pack
```

En executar-lo ens mostrarà el següent missatge:

```shell
Symfony operations: 1 recipe (5a8f9ff66bdb49d40606adc556254e91)
  -  WARNING  symfony/apache-pack (>=1.0): From ...

    Do you want to execute this recipe?
    [y] Yes
    [n] No
    [a] Yes for all packages, only for the current installation session
    [p] Yes permanently, never ask again for this project
    (defaults to n): 
```
Al que respondrem `y` o `p` si volem que no ens torne a preguntar.

---

#### Rutes amb paràmetres

Existeixen algunes rutes que tenen parts variables. 

> http://movies-symfony/movies/54

Anem a crear un nou mètode del controlador en el nostre espai de noms
`Controller` dins de la carpeta `src`. 

`MovieController::show`, que mostrarà la
fitxa de la pel·lícula segons el codi

---

```php
namespace App\Controller;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
class MovieController
{
    /**
     * @Route("/movies/{id}", name="movies_show")
     */
    public function show($id)
    {
        return new Response("Movie data with id: $id");
    }
}
```
--- 
```php
namespace App\Controller;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
class MovieController
{
    private array $movies = [
        ["id"=>"2", "title" => "Ava", "tagline" => "Kill. Or be killed", 
            "release_date" => "25/09/2020"],
        ["id" => "3", "title" => "Bill &Ted Face the Music", 
            "tagline" => "The future awaits", "release_date" => "24/09/2020"],
        ["id" => "4", "title" => "Hard Kill", 
            "tagline" => "Take on a madman. Save the world.", "release_date" => "14/09/2020"],
        ["id" => "5", "title" => "The Owners", "tagline" => "", 
            "release_date" => "10/05/2020"],
        ["id" => "6", "title" => "The New Mutants", 
            "tagline" => "It's time to face your demons.", "release_date" => "20/04/2020"],        
    ];


    /**
     * @Route("/movies/{id}", name="movies_show")
     */
    public function show($id)
    {
        $result = array_filter($this->movies,
            function($movie) use ($id)
            {
                return $movie["id"] == $id;
            });
        if (count($result) > 0)
        {
            $response = "";
            $result = array_shift($result);
            $response .= "<ul><li>" . $result["title"] . "</li>" .
            "<li>" . $result["tagline"] . "</li>" .
            "<li>" . $result["release_date"] . "</li></ul>";
            return new Response("<html><body>$response</body></html>");
        }
        else
            return new Response("Movie not found");
    }
}
```
---

#### Afegir requisits a les wildcards

Imaginem que volem definir un cercador de pel·lícules:
```php
    /**
     * @Route("/movies/{text}", name="movies_filter")
     */
    public function filter($text)
    {
        $result = array_filter($this->movies,
            function($movie) use ($text)
            {
                return strpos($movie["title"], $text) !== false;                
            });
        $response = "";
        if (count($result) > 0)
        {
            foreach ($result as $movie) {
                $response .= "<ul><li>" . $movie["title"] . "</li>" .
            "<li>" . $movie["tagline"] . "</li>" .
            "<li>" . $movie["release_date"] . "</li></ul>";
            }
            return new Response("<html><body>$response</body></html>");
        }
        else
            return new Response("No movies found");
    }
}
```
---
### Afegir requisits a les wildcards

Si intentem llançar la URL anterior
(http://movies-symfony/movies/The), obtindrem com a resultat
"Movie not found", que és el missatge corresponent al controlador
anterior (la fitxa de pel·lícula) quan no es trobava la pel·lícula amb el
codi indicat. És a dir, s'ha llançat el controlador equivocat, i el
motiu és simple: hem definit dues rutes a priori diferents:

- `/movies/{id}` per a la fitxa de la pel·lícula
- `/movies/{text}` per a cercar pel·lícules pel títol

---

```php
@Route("/movies/{id}", name="movies_show", requirements={"id"="\d+"})
```
Des de Symfony 4.1, també es pot emprar aquesta altra notació més
abreujada per a incloure el requeriment en el wildcard:
```
@Route("/movies/{id}<\d+>", name="movies_show")
```
---

### Afegir valors per defecte a les _wildcards_

```php
/**
 * @Route("/movies/{id}", name="movies_show", requirements={"id"="\d+"})
 */
public function show($id = 2)
```

encara que des de Symfony 4.1 també es pot especificar en la pròpia
anotació, d'aquesta altra forma:

```php
@Route("/movies/{id}<\d+>?2", name="movies_show")
```
Per a més informació podeu consultar la documentació oficial de Symfony:
[Routing](https://symfony.com/doc/current/routing.html)


---
<!-- _class: lead -->

# Twig

![bg right width:60%](../assets/twig.png)

---


## Definint plantilles de vistes amb Twig


La filosofia d'utilitzar motors de plantilles com Twig és separar tot
el possible el codi PHP de l'estructura HTML de la pàgina, de manera
que tota la lògica de negoci queda fora de la vista (en el controlador,
normalment), i en aquesta deixem el necessari per a mostrar el contingut
al client.

---

### La nostra primera plantilla

La classe del controlador ha d'heretar d'`AbstractController`
(incorporant aquesta classe del seu corresponent espai de noms):

```php
namespace App;
... 
use Symfony;

class NameController extends AbstractController 
```

---
### La nostra primera plantilla

Açò ho farem per a poder utilitzar algunes de les facilitats que ens
dona `AbstractController`, com per exemple el mètode `render` per a
renderizar vistes. 

Les vistes s'emmagatzemen en la carpeta `templates` i tenen l'extensió `.html.twig.`

#### home.html.twig :

```html
<html>
    <body>
        <h1>Movies</h1>
        <h2>Welcome to Movie FX</h2>
        <p>Home</p>
    </body>
</html>
```
---

### src/Controller/HomeController.php

```php
namespace App\Controller;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
class HomeController extends AbstractController
{
... 

/**
* @Route("/", name="home")
*/
public function home()
{
    return $this->render('home.html.twig');
}
```
---


### Plantilles amb parts variables

```php
namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class MovieController extends AbstractController
```

---
#### movies_show.html.twig
```ruby
<h1>Movie data</h1>

<h2>{{ movie.title }}</h2>

<p>Tagline: {{ movie.tagline }}</p>

<p>Release date: {{ movie.release_date }}</p>
```
---

### MovieController::show

```php
/**
  * @Route("/movies/{id}", name="movies_show", requirements={"id"="\d+"})
  */

    public function show($id = 2)
    {
        $result = array_filter($this->movies,
            function($movie) use ($id)
            {
                return $movie["id"] == $id;
            });
        if (count($result) > 0)
        {
            return $this->render('movies_show.html.twig', array(
                'movie' => array_shift($result)
            ));
        }
        else
            return new Response("Movie not found");
    }
```
---
### Estructures de control en plantilles

```php
    public function show($id = 2)
    {
        $result = array_filter($this->movies,
            function($movie) use ($id)
            {
                return $movie["id"] == $id;
            });
        if (count($result) > 0)
        {
            return $this->render('movies_show.html.twig', array(
                'movie' => array_shift($result)
            ));
        }
        else
            return $this->render('movies_show.html.twig', array(
                'movie' => null
        ));
    }
```
---

```pyton
<html>
<body>
<h1>Movie data</h1>
    {% if movie %}
    <ul>
        <li><strong>{{ movie.title }}</strong></li>
        <li><strong>Tagline</strong>: {{ movie.tagline }}</li>
        <li><strong>Release date</strong>: {{ movie.release_date }}</li>
    </ul>
    {% else %}
        <p>Movie not found</p>
    {% endif %}
    </body>
</html>
```
---

```php
<h1>Movies</h1>
{% if movies %} 
    <ul>
    {% for movie in movies %}  
        <li><strong>{{ movie.title }}</strong></li>
        <li><strong>Tagline</strong>: {{ movie.tagline }}</li>
        <li><strong>Release date</strong>: {{ movie.release_date }}</li>
    </ul>
    {% endfor %} 
{% else %}
    <p>No movies found</p>
{% endif %}
```

---
Així, el codi del controlador es limitarà a filtrar les i
a passar-li'ls a la vista:

```php
   public function filter($text)
    {
        $result = array_filter($this->movies,
            function($movie) use ($text)
            {
                return strpos($movie["title"], $text) !== false;                
            });
        $response = "";
        if (count($result) > 0)
        {
            return $this->render('movies_filter.html.twig', array(
                'movies' => $result
                ));        
        }        
    }
```
---


### Herència de plantilles
#### `templates/base.html.twig`
--- 

```php
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}{% endblock %}

        {% block javascripts %}{% endblock %}
    </head>
    <body>
        {% block body %}{% endblock %}
    </body>
</html>
```
---


#### `home.html.twig` 

```php
{% extends 'base.html.twig' %}

{% block title %}Movies{% endblock %} {% block body %}

<h1>Movies</h1>

<p>Welcome to Movies FX Site!</p>

{% endblock %}
``` 
---

#### `movies_show.html.twig`.

```php
{% extends 'base.html.twig' %}
{% block title %}Movies{% endblock %}

{% block body %}   

<h1>Movie data</h1>
    {% if movie %}
    <ul>
        <li><strong>{{ movie.title }}</strong></li>
        <li><strong>Tagline</strong>: {{ movie.tagline }}</li>
        <li><strong>Release date</strong>: {{ movie.release_date }}</li>
    </ul>
    {% else %}
        <p>Movie not found</p>
    {% endif %}
{% endblock %}
```
---

#### `movies_filter.html.twig`:

```php
{% extends 'base.html.twig' %}
{% block title %}Movies{% endblock %}

{% block body %}   
<h1>Movies</h1>
{% if movies %} 
    {% for movie in movies %}  
    <ul>
        <li><strong>{{ movie.title }}</strong></li>
        <li><strong>Tagline</strong>: {{ movie.tagline }}</li>
        <li><strong>Release date</strong>: {{ movie.release_date }}</li>
    </ul>
    {% endfor %} 
{% else %}
    <p>No movies found</p>
{% endif %}
{% endblock %}
```
---

### Incloure plantilles dins d'altres

#### `movie_data.html.twig`:

```php
<ul>
    <li><strong>{{ movie.title }}</strong></li>
    <li><strong>Tagline</strong>: {{ movie.tagline }}</li>
    <li><strong>Release date</strong>: {{ movie.release_date }}</li>
</ul>
```

---
#### `movies_show`...

```php
{% extends 'base.html.twig' %}
{% block title %}Movies{% endblock %}

{% block body %}   

<h1>Movie data</h1>
    {% if movie %}
        {{ include ('movie_data.html.twig', {'movie': movie }) }}
    {% else %}
        <p>Movie not found</p>
    {% endif %}
{% endblock %}
```
---

#### `movies_filter`:

```php

{% extends 'base.html.twig' %}
{% block title %}Movies{% endblock %}

{% block body %}   
<h1>Movies</h1>
{% if movies %} 
    {% for movie in movies %}  
        {{ include ('movie_data.html.twig', {'movie': movie }) }}
    {% endfor %} 
{% else %}
    <p>No movies found</p>
{% endif %}
{% endblock %}
```
---

```shell
symfony-projects
├── movies
│   ├── bin
│   ├── composer.json
│   ├── composer.lock
│   ├── config
│   ├── public
│   ├── src
│   ├── templates
│   └── vendor
└── 00-vicent-symfony
    ├── bin
    ├── composer.json
    ├── composer.lock
    ├── config
    ├── public
    ├── src
    ├── templates
    └── vendor
```

---
### Enllaços a rutes i a elements estàtics

Per a finalitzar aquest apartat d'edició de plantilles, ens queden dos
aspectes importants a tractar:

-   Com incloure contingut estàtic (fulles d'estil, imatges... i tot el
    que, en general, estiga dins de la carpeta "public" del projecte)
-   Com afegir enllaços a altres rutes

---
#### Afegir contingut estàtic en plantilles

Per a il·lustrar com afegir contingut estàtic en plantilles, anem a
definir en la nostra carpeta `public` de la web de pel·lícules una
subcarpeta `css`, i dins un arxiu `styles.css` (que quedarà, per tant, en
`public/css/styles.css`. Definim dins un estil bàsic per a provar. Per
exemple:

```css
    body { background-color: #99ccff; } 
    h1 { border-bottom: 1px solid black; }
```
---

### `base.html.twig`

```php
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}
        <link href="{{ asset('css/styles.css') }}"
         rel="stylesheet" />
        {% endblock %}
        {% block javascripts %}{% endblock %}
    </head>
    <body>
        {% block body %}{% endblock %}
    </body>
</html>
```
---

De la mateixa manera, si tinguérem una imatge, per exemple,
`public/images/image.png`, podríem afegir-la en la plantilla  amb un cosa així:


```php
<img src="{{ asset('images/image.png') }}" />
```
Podem també emprar rutes absolutes, emprant la instrucció `absolute_url`:

```php
<img src="{{ absolute_url(asset('images/image.png')) }}" />
```

---
En el cas d'arxius javascript, s'afegirien en el bloc `javascripts` de la plantilla base (o
d'alguna subplantilla, si es vol). Per exemple, suposant que tenim un
arxiu `library.js` penjant de la subcarpeta `public/js`, faríem alguna cosa
així:

---
```php
{% block javascripts %}
<script src="{{ asset('js/library.js') }}"></script>
{% endblock %}
```
---

#### Enllaçar a altres rutes de l'aplicació

Si el que volem és definir un enllaç a una altra ruta o pàgina de la
nostra aplicació, en aqueix cas utilitzem la funció `path` per a indicar
el nom (`name`) que hàgem assignat a la ruta a la qual volem anar. Per
exemple, si volem anar a la fitxa d'una pel·lícula el codi del qual està
emmagatzemat en la variable `id`, faríem alguna cosa així:


```php
<a href="{{ path('movies_show', {'id': id}) }}">...</a>
```
---
### Altres característiques interessants de Twig

#### Ús de filtres

Els filtres en Twig s'activen
mitjançant la barra vertical (`|`), seguida del filtre a aplicar. Per exemple,
si volem mostrar el nom del títol  en majúscules, faríem alguna cosa
així:

```php
{{ movie.title | upper }}

{{ movie.releaseDate | date("d/m/Y")}}
```
---

#### Comentaris

És possible també afegir línies de comentaris en les plantilles Twig,
mitjançant la sintaxi `{# ... #}`:

```php
{# Açò és un comentari #}
```
---
#### Reutilitzar contingut de plantilles pare

```parent
{% block stylesheets %}
    {{ parent() }}
    <link href="{{ asset('css/some_styles.css') }}" rel="stylesheet" />
{% endblock %}
{% endraw %}
```
---
#### Cicles

L'opció _cycle_ és molt útil quan volem alternar cíclicament certs valors
en un bucle. Per exemple, per a mostrar un llistat amb 10 files i estils
de fila alterns, podem fer alguna cosa així:

```ruby
{% for i in 1..10 %}
    <div class="{{ cycle(['par', 'impar'], i) }}">
    ...
    </div>
{% endfor %}
```
---

#### Altres opcions

Existeixen altres opcions que no hem vist i podeu consultar
en la [web oficial de Twig]([https://twig.symfony.com/).


---
## 4. Exercicis

### Exercici 2.1
Adapta la plantilla base basant-te en la del projecte `Movies`.

Afig a l'array de pel·lícules la clau `poster` amb el nom del fitxer 
i canvia el format de la data a `DateTime` o `timestamp`. 

Modifica la plantilla de `movies_show.html.twig` 
    perque s'assemble a les de projecte `Movies`.